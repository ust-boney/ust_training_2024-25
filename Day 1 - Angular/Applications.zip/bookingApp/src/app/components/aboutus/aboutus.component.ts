import { Component } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  imports: [],
  templateUrl: './aboutus.component.html',
  styleUrl: './aboutus.component.css'
})
export class AboutusComponent {
  aboutusDetails = "AboutUs.com is an inactive internet domain directory wiki. It lists websites along with information about their content. As a wiki, AboutUs allows Internet users to add entries or modify information. AboutUs.com has since become a wiki for more than just websites. The site allows pages to be created for people, places, and almost anything else." +

"Ray King, Jay Westerdal, and Paul Stahura founded AboutUs in 2005. Later in 2006 a small staff of five people in Portland, Oregon, United States developed out the site. The staff expanded to more than thirty people and two continents with an office in Lahore, Pakistan. From May 2007 to early 2011, Ward Cunningham, developer of the first wiki, was the chief technology officer of AboutUs. " +

"AboutUs attracted at least 1.4 million U.S. visitors in July 2008.[1] They used to use the domain name AboutUs.org, but moved to new site under AbutUs.com in May 2010.[2] Traffic and revenue started declining sharply and in 2013 AboutUs.com and its assets were sold to Omkarasana LLC, a Colorado Limited Liability Company located in Denver. The new company has since redesigned the website, migrated its infrastructure over to Amazon Web Services, and attempted to increase visitors and revenue. However, as of February 2024, activity on the site has all but ceased, with only one edit being performed since November 2018.[3]" +

"Website contents" +
"There were more than ten million entries on AboutUs.com as of March 2008, with about 25,000 pages being added a day during that period.[4] Most entries were created by a web robot (bot); web searches by users direct the bot to create a page for a web domain. In many cases the content is simply a republication of the contents of the About us, About me, or similar page on the website. Such pages typically describe the entity that owns the site, and may include self-promotional information, which AboutUs.com does not restrict. In many other cases the content of an entry consists of the whois data for the website. As of February 2014, there were more than 20 million entries.";

componentName = "About us";

}
