import { Component } from '@angular/core';

@Component({
  selector: 'app-bookinghistory',
  imports: [],
  templateUrl: './bookinghistory.component.html',
  styleUrl: './bookinghistory.component.css'
})
export class BookinghistoryComponent {

}
