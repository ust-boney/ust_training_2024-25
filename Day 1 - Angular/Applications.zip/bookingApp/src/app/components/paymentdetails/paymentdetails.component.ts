import { Component } from '@angular/core';

@Component({
  selector: 'app-paymentdetails',
  imports: [],
  templateUrl: './paymentdetails.component.html',
  styleUrl: './paymentdetails.component.css'
})
export class PaymentdetailsComponent {

}
