import { Component } from '@angular/core';

@Component({
  selector: 'app-searchflight',
  imports: [],
  templateUrl: './searchflight.component.html',
  styleUrl: './searchflight.component.css'
})
export class SearchflightComponent {

}
