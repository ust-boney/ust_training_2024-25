import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  appliacationName:string = 'Employee Management App';
  frameworkName:string = 'Angular';
  developerName:string = 'Nikhil Shah';
  teamSize:number = 20;
  isLive:boolean = false;

  firstNumber:number = 20;
  secondNumber:number = 30;
  isEmployeePermenant:boolean = false;




  greetUser()
  {
    alert("Hello User");
  }
  changeAppName()
  {
    this.appliacationName ="New Employee Portal for People management";
  }


}
