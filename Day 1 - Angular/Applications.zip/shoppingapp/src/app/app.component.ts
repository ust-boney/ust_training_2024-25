import { NgFor } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,NgFor],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
    
    title:string = "Nikhil's Shopping App";
    productsList:string[] = ['Shoes','Tshirt','Cold-Drinks','Head-Phones','Mobile']; 
    productDetails = {
      pId:101,
      pName:'Pepsi',
      pCategory:'Cold-Drink',
      pPrice:50,pIsInStock:false,
      pImage:'./images/pepsi.jpg' }


}
